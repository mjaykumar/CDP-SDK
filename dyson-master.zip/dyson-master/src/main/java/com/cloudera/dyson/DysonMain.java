package com.cloudera.dyson;

import com.cloudera.cdp.authentication.credentials.CdpCredentials;
import com.cloudera.cdp.authentication.credentials.CdpProfileCredentialsProvider;
import com.cloudera.cdp.CdpServiceException;
import com.cloudera.cdp.datahub.api.DatahubClient;
import com.cloudera.cdp.datahub.api.DatahubClientBuilder;
import com.cloudera.cdp.datahub.model.ClusterSummary;
import com.cloudera.cdp.datahub.model.DeleteClusterRequest;
import com.cloudera.cdp.datahub.model.GetClusterHostStatusResponse;
import com.cloudera.cdp.datahub.model.GetClusterHostStatusRequest;
import com.cloudera.cdp.datahub.model.HostStatus;
import com.cloudera.cdp.datahub.model.ListClustersRequest;
import com.cloudera.cdp.datahub.model.ListClustersResponse;
import com.cloudera.cdp.datalake.api.DatalakeClient;
import com.cloudera.cdp.datalake.api.DatalakeClientBuilder;
import com.cloudera.cdp.datalake.model.Datalake;
import com.cloudera.cdp.datalake.model.DeleteDatalakeRequest;
import com.cloudera.cdp.datalake.model.ListDatalakesRequest;
import com.cloudera.cdp.datalake.model.ListDatalakesResponse;
import com.cloudera.cdp.environments.api.EnvironmentsClient;
import com.cloudera.cdp.environments.api.EnvironmentsClientBuilder;
import com.cloudera.cdp.environments.model.DeleteEnvironmentRequest;
import com.cloudera.cdp.environments.model.EnvironmentSummary;
import com.cloudera.cdp.environments.model.ListEnvironmentsRequest;
import com.cloudera.cdp.environments.model.ListEnvironmentsResponse;
import com.cloudera.cdp.ml.api.MlClient;
import com.cloudera.cdp.ml.api.MlClientBuilder;
import com.cloudera.cdp.ml.model.DeleteWorkspaceRequest;
import com.cloudera.cdp.ml.model.ListWorkspacesRequest;
import com.cloudera.cdp.ml.model.ListWorkspacesResponse;
import com.cloudera.cdp.ml.model.Workspace;

import java.util.List;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DysonMain {
  
  public static final Logger logger = LogManager.getLogger("Dyson");

  private final CdpProfileCredentialsProvider credProvider;

  private final EnvironmentsClient envClient;
  private final DatalakeClient dlClient;
  private final DatahubClient dhClient;
  private final MlClient mlClient;

  private final String profileName;

  private static final Options OPTIONS = new Options();
  private static final Option GENERATE_OPT = new Option("g", "generate", false,
      "Generate list of resources to be deleted.");
  private static final Option DELETE_OPT = new Option("d", "delete", false,
      "Delete resources specified on stdin.");
  private static final Option EXCLUDE_ENV_OPT = new Option("ee", "exclude-env",
      true, "Comma-separated list of environments to exclude from deletion. " +
      "Only for use with -g/--generate option.");
  private static final Option EXCLUDE_DH_OPT = new Option("edh", "exclude-dh",
      true, "Comma-separated list of Datahubs to exclude from deletion, if " +
      "they would otherwise be deleted. Only for use with -g/--generate " +
      "option.");
  private static final Option EXCLUDE_ML_OPT = new Option("eml", "exclude-ml",
      true, "Comma-separated list of ML workspaces to exclude from deletion, " +
      "if they would otherwise be deleted. Only for use with the -g/--generate " +
      "option.");
  private static final Option CLOUD_RESOURCE_OPT = new Option("c",
      "cloud-resource-ids", false, "Print (as comments) cloud-provider " +
      "resource IDs for CDP objects that are identified for deletion.");
  private static final Option VERBOSE_OPT = new Option("v", "verbose", false,
      "Enable debug logging.");
  private static final Option PROFILE_OPT = new Option("p", "profile", true,
      "The CDP credentials profile to use");
  private static final Option DRY_RUN_OPT = new Option("dr", "dry-run", false,
      "When supplied with --delete, will not actually delete any resources");

  static {
    OPTIONS.addOption(GENERATE_OPT);
    OPTIONS.addOption(DELETE_OPT);
    OPTIONS.addOption(EXCLUDE_ENV_OPT);
    OPTIONS.addOption(EXCLUDE_DH_OPT);
    OPTIONS.addOption(EXCLUDE_ML_OPT);
    OPTIONS.addOption(CLOUD_RESOURCE_OPT);
    OPTIONS.addOption(VERBOSE_OPT);
    OPTIONS.addOption(PROFILE_OPT);
    OPTIONS.addOption(DRY_RUN_OPT);
  }
  
  private DysonMain(String profileName) {
    this.profileName = profileName;
    credProvider = new CdpProfileCredentialsProvider(profileName);

    envClient = EnvironmentsClientBuilder.defaultBuilder()
        .withCredentials(credProvider).build();
    dlClient = DatalakeClientBuilder.defaultBuilder()
        .withCredentials(credProvider).build();
    dhClient = DatahubClientBuilder.defaultBuilder()
        .withCredentials(credProvider).build();
    mlClient = MlClientBuilder.defaultBuilder()
        .withCredentials(credProvider).build();
  }

  private List<EnvironmentSummary> listAllEnvironments() {
    ListEnvironmentsResponse response = envClient.listEnvironments(
        new ListEnvironmentsRequest());
    return response.getEnvironments();
  }

  private List<Datalake> listAllDatalakes() {
    ListDatalakesResponse response = dlClient.listDatalakes(
        new ListDatalakesRequest());
    return response.getDatalakes();
  }

  private List<ClusterSummary> listAllClusters() {
    ListClustersResponse response = dhClient.listClusters(
        new ListClustersRequest());
    return response.getClusters();
  }

  private List<Workspace> listAllMlWorkspaces() {
    ListWorkspacesResponse response = mlClient.listWorkspaces(
        new ListWorkspacesRequest());
    return response.getWorkspaces();
  }

  private List<HostStatus> getDhClusterHostStatus(String clusterCrn) {
    GetClusterHostStatusRequest request = new GetClusterHostStatusRequest();
    request.setClusterName(clusterCrn);
    return dhClient.getClusterHostStatus(request).getHosts();
  }

  private void deleteDhCluster(ClusterSummary cluster, boolean dryRun) {
    DeleteClusterRequest request = new DeleteClusterRequest();
    request.setClusterName(cluster.getCrn());
    request.setForce(false);
    logger.debug("delete datahub request: {}", request);
    if (!dryRun) {
      try {
        dhClient.deleteCluster(request);
      } catch (CdpServiceException cdpse) {
        logger.error("Error deleting " + cluster.getCrn());
        cdpse.printStackTrace();
      }
    }
  }

  private void deleteMlWorkspace(Workspace workspace, boolean dryRun) {
    DeleteWorkspaceRequest request = new DeleteWorkspaceRequest();
    request.setWorkspaceName(workspace.getInstanceName());
    request.setEnvironmentName(workspace.getEnvironmentName());
    request.setForce(false);
    request.setRemoveStorage(true);
    logger.debug("delete ML workspace request: {}", request);
    if (!dryRun) {
      try {
        mlClient.deleteWorkspace(request);
      } catch (CdpServiceException cdpse) {
        System.err.println("Error deleting " + workspace.getCrn());
        cdpse.printStackTrace();
      }
    }
  }

  private void deleteDatalake(Datalake datalake, boolean dryRun) {
    DeleteDatalakeRequest request = new DeleteDatalakeRequest();
    request.setDatalakeName(datalake.getCrn());
    request.setForce(false);
    logger.debug("delete datalake request: {}", request);
    if (!dryRun) {
      try {
        dlClient.deleteDatalake(request);
      } catch (CdpServiceException cdpse) {
        System.err.println("Error deleting " + datalake.getCrn());
        cdpse.printStackTrace();
      }
    }
  }

  private void deleteEnvironment(EnvironmentSummary env, boolean dryRun) {
    DeleteEnvironmentRequest request = new DeleteEnvironmentRequest();
    request.setEnvironmentName(env.getCrn());
    logger.debug("delete environment request: {}", request);
    if (!dryRun) {
      try {
        envClient.deleteEnvironment(request);
      } catch (CdpServiceException cdpse) {
        System.err.println("Error deleting " + env.getCrn());
        cdpse.printStackTrace();
      }
    }
  }

  private static boolean isEnvMarkedForDeletion(DeletionResources delResources,
      String envCrn) {
    for (EnvironmentSummary e: delResources.envs) {
      if (e.getCrn().equals(envCrn))
        return true;
    }
    return false;
  }

  private static void removeEnvFromDeletion(DeletionResources delResources,
      String envCrn) {
    for (EnvironmentSummary e : delResources.envs) {
      if (e.getCrn().equals(envCrn)) {
        logger.debug("Indirectly excluding env {} from cleanup", envCrn);
        delResources.envs.remove(e);
        break;
      }
    }
  }

  private DeletionResources identifyResourcesToDelete(
      Set<String> excludedEnvNames, Set<String> excludedDhNames,
      Set<String> excludedMlNames) {

    DeletionResources deletionResources = new DeletionResources();

    List<EnvironmentSummary> allEnvs = listAllEnvironments();
    List<Datalake> allDlClusters = listAllDatalakes();
    List<ClusterSummary> allDhClusters = listAllClusters();
    List<Workspace> allMlWorkspaces = listAllMlWorkspaces();

    Set<String> excludedEnvCrns = new HashSet<String>();
    Set<String> excludedDhCrns = new HashSet<String>();

    /***** Environments *****/

    for (EnvironmentSummary e : allEnvs) {
      if (excludedEnvNames.contains(e.getEnvironmentName())) {
        logger.debug("Excluding env {} from cleanup", e.getEnvironmentName());
        excludedEnvCrns.add(e.getCrn());
        excludedEnvNames.remove(e.getEnvironmentName());
      } else {
        logger.debug("Marking env {} for cleanup", e.getEnvironmentName());
        deletionResources.envs.add(e);
      }
    }

    if (excludedEnvNames.size() > 0) {
      logger.error("Could not find CRNs for some excluded environments: {}",
          String.join(", ", excludedEnvNames));
      logger.error("Exiting");
      System.exit(1);
    }
    logger.debug("Excluding {} environments from cleanup. Marked {} " +
        "environments for deletion.", excludedEnvCrns.size(),
        deletionResources.envs.size());

    /***** Datahubs *****/

    for (ClusterSummary c : allDhClusters) {
      if (excludedEnvCrns.contains(c.getEnvironmentCrn())) {
        logger.debug("Indirectly excluding DH cluster {} from cleanup", c.getClusterName());
      } else if (excludedDhNames.contains(c.getClusterName())) {
        logger.debug("Directly excluding DH cluster {} from cleanup", c.getClusterName());
        excludedDhNames.remove(c.getClusterName());
        removeEnvFromDeletion(deletionResources, c.getEnvironmentCrn());
      } else {
        logger.debug("Marking DH cluster {} for deletion", c.getClusterName());
        deletionResources.dhClusters.add(c);
      }
    }
    if (excludedDhNames.size() > 0) {
      logger.error("Could not find some excluded datahubs: {}",
          String.join(", ", excludedDhNames));
      logger.error("Exiting");
      System.exit(1);
    }
    logger.debug("Excludng {} datahub clusters from cleanup. Marked {} " +
        "datahub clusters for deletion",
        (allDhClusters.size() - deletionResources.dhClusters.size()),
        deletionResources.dhClusters.size());

    /***** ML workspaces *****/

    for (Workspace w : allMlWorkspaces) {
      if (excludedEnvCrns.contains(w.getEnvironmentCrn())) {
        logger.debug("Indirectly excluding ML workspace {} from cleanup",
            w.getInstanceName());
      } else if (excludedMlNames.contains(w.getInstanceName())) {
        logger.debug("Directly excluding ML workspace {} from cleanup",
            w.getInstanceName());
        excludedMlNames.remove(w.getInstanceName());
        removeEnvFromDeletion(deletionResources, w.getEnvironmentCrn());
      } else {
        logger.debug("Marking ML workspace {} for deletion", w.getInstanceName());
        deletionResources.mlWorkspaces.add(w);
      }
    }
    if (excludedMlNames.size() > 0) {
      logger.error("Could not find some excluded ML workspaces: {}",
          String.join(", ", excludedMlNames));
      logger.error("Exiting");
      System.exit(1);
    }
    logger.debug("Excludng {} ML workspaces from cleanup. Marked {} " +
       "ML workspaces for deletion.",
       (allMlWorkspaces.size() - deletionResources.mlWorkspaces.size()),
       deletionResources.mlWorkspaces.size());

    /***** Datalakes *****/

    for (Datalake d : allDlClusters) {
      if (excludedEnvCrns.contains(d.getEnvironmentCrn())) {
        logger.debug("Excluding datalake {} from cleanup", d.getDatalakeName());
      } else if (!isEnvMarkedForDeletion(deletionResources, d.getEnvironmentCrn())) {
        logger.debug("Indirectly excluding datalake {} from cleanup",
            d.getDatalakeName());
      } else {
        logger.debug("Marking {} for deletion", d.getDatalakeName());
        deletionResources.dlClusters.add(d);
      }
    }
    logger.debug("Excluding " +
        (allDlClusters.size() - deletionResources.dlClusters.size()) +
        " datalakes from cleanup. Marked " + deletionResources.dlClusters.size() +
        " datalakes for deletion.");
 
    return deletionResources;
  }

  private void promptToConfirmDelete() {
    System.out.print("\nDo you wish to proceed to delete the above resources?" +
        " Type \"yes\" if so... ");
    Scanner sysIn = new Scanner(System.in);
    String response = sysIn.nextLine();
    if ("yes".equals(response)) {
      System.out.println("Proceeding to delete...");
    } else {
      System.err.println("Aborting...");
      System.exit(1);
    }
  }

  private void deleteResourcesMarkedForDeletion(
      DeletionResources deletionResources, boolean dryRun) {
    System.out.println("\nDeleting datahubs...");
    for (ClusterSummary c : deletionResources.dhClusters) {
      System.out.println("\tDeleting datahub cluster " + c.getClusterName());
      deleteDhCluster(c, dryRun);
    }

    System.out.println("\nDeleting ML workspaces...");
    for (Workspace w : deletionResources.mlWorkspaces) {
      System.out.println("\tDeleting ML workspace " + w.getInstanceName());
      deleteMlWorkspace(w, dryRun);
    }

    System.out.println("\nDeleting datalakes...");
    for (Datalake d : deletionResources.dlClusters) {
      System.out.println("\tDeleteing datalake " + d.getDatalakeName());
      deleteDatalake(d, dryRun);
    }

    System.out.println("\nDeleting environments...");
    for (EnvironmentSummary e : deletionResources.envs) {
      System.out.println("\tDeleting environment " + e.getEnvironmentName());
      deleteEnvironment(e, dryRun);
    }
  }

  private void generate(Set<String> excludedEnvNames,
      Set<String> excludedDhNames, Set<String> excludedMlNames,
      boolean printInstanceIds) {
    logger.debug("Identifying resources to clean up...");
    DeletionResources resources = identifyResourcesToDelete(excludedEnvNames,
        excludedDhNames, excludedMlNames);

    logger.debug("Marked the following for deletion...");
    InputOutputFormat.printResourcesToStream(resources, System.out,
        printInstanceIds, profileName);

    RestBasedDwClient dwClient = new RestBasedDwClient();
    dwClient.listAllDataCatalogs();
  }

  private void delete(boolean dryRun) {
    logger.debug("Parsing resources to clean up...");
    DeletionResources resources = InputOutputFormat.parseResourcesFromStream(
        System.in);

    deleteResourcesMarkedForDeletion(resources, dryRun);
  }

  private static void validateCmdLineOptions(CommandLine cmd) {
    // Can only do one of generate or delete.
    if (cmd.hasOption(GENERATE_OPT.getOpt()) &&
        cmd.hasOption(DELETE_OPT.getOpt())) {
      throw new RuntimeException("Can only use one of '" +
          GENERATE_OPT.getLongOpt() + "' or '" +
          DELETE_OPT.getLongOpt() + "' options");
    } else if (!(cmd.hasOption(GENERATE_OPT.getOpt()) ||
          cmd.hasOption(DELETE_OPT.getOpt()))) {
      throw new RuntimeException("Must have one of '" +
          GENERATE_OPT.getLongOpt() + "' or '" +
          DELETE_OPT.getLongOpt() + "' options");
    }

    // Exclude option not supported with delete operation.
    if (cmd.hasOption(DELETE_OPT.getOpt()) &&
        (cmd.hasOption(EXCLUDE_ENV_OPT.getOpt()) ||
         cmd.hasOption(EXCLUDE_DH_OPT.getOpt()))) {
      throw new RuntimeException("Exclude options can " +
          "only be used with 'generate'.");
    }
  }

  private static Set<String> extractExcludesForOption(CommandLine cmd, Option opt) {
      Set<String> excludes = new HashSet<String>();
      if (cmd.hasOption(opt.getOpt())) {
        String excludesArgValue = cmd.getOptionValue(opt.getOpt());

        for (String s : excludesArgValue.split(",")) {
          excludes.add(s);
        }
      }

      return excludes;
  }

  public static void main(String[] args) throws ParseException {

    CommandLine cmd = (new DefaultParser()).parse(OPTIONS, args);

    if (cmd.hasOption(VERBOSE_OPT.getOpt())) {
      Configurator.setRootLevel(Level.DEBUG);
    }

    validateCmdLineOptions(cmd);

    boolean printInstanceIds = false;
    if (cmd.hasOption(GENERATE_OPT.getOpt()) &&
        cmd.hasOption(CLOUD_RESOURCE_OPT.getOpt())) {
      printInstanceIds = true;
    }

    boolean dryRun = false;
    if (cmd.hasOption(DRY_RUN_OPT.getOpt())) {
      dryRun = true;
    }

    String profileName = "default";
    if (cmd.hasOption(PROFILE_OPT.getOpt())) {
      profileName = cmd.getOptionValue(PROFILE_OPT.getOpt());
    }

    if (cmd.hasOption(GENERATE_OPT.getOpt())) {
      Set<String> excludedEnvNames = extractExcludesForOption(cmd, EXCLUDE_ENV_OPT);
      Set<String> excludedDhNames = extractExcludesForOption(cmd, EXCLUDE_DH_OPT);
      Set<String> excludedMlNames = extractExcludesForOption(cmd, EXCLUDE_ML_OPT);

      new DysonMain(profileName).generate(excludedEnvNames, excludedDhNames,
          excludedMlNames, printInstanceIds);
    } else if (cmd.hasOption(DELETE_OPT.getOpt())) {
      new DysonMain(profileName).delete(dryRun);
    }

  }

}
