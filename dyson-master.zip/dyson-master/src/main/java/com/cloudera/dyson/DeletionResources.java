package com.cloudera.dyson;

import com.cloudera.cdp.datahub.model.ClusterSummary;
import com.cloudera.cdp.datalake.model.Datalake;
import com.cloudera.cdp.environments.model.EnvironmentSummary;
import com.cloudera.cdp.ml.model.Workspace;

import java.util.HashSet;
import java.util.Set;

public class DeletionResources {
  public final Set<EnvironmentSummary> envs = new HashSet<EnvironmentSummary>();
  public final Set<Datalake> dlClusters = new HashSet<Datalake>();
  public final Set<ClusterSummary> dhClusters = new HashSet<ClusterSummary>();
  public final Set<Workspace> mlWorkspaces = new HashSet<Workspace>();
}
