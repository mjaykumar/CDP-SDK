package com.cloudera.dyson;

import java.io.IOException;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class RestBasedDwClient {

  public void listAllDataCatalogs() {
    String sessionToken = "eyJraWQiOm51bGwsImFsZyI6IkVTMjU2In0.eyJpc3MiOiJBbHR1cyBJQU0iLCJhdWQiOiJBbHR1cyBJQU0iLCJqdGkiOiIzckExc3M1d2xKR0FFNTFpZWdwZ2FRIiwiaWF0IjoxNTcyNjQ5MDAxLCJleHAiOjE1NzI2OTIyMDEsInN1YiI6ImNybjphbHR1czppYW06dXMtd2VzdC0xOjU1OGJjMWQyLTg4NjctNDM1Ny04NTI0LTMxMWQ1MTI1OTIzMzp1c2VyOmYyODFmMmMwLTQ3NTgtNDczNi04Njg1LWUxZmNiMzVmMmI4OCJ9.OeTmC4OHWQWqnpOAB2KsaGx-2Gv2L24dloFjCBueNJvb31nbfw8qYnc6ltlw9GhKvfjoipfHDbnvC0KbhOuiQQ";

    HttpClient httpClient = HttpClientBuilder.create().build();
    try {
      // specify the host, protocol, and port
      HttpHost target = new HttpHost("cloudera.us-west-1.cdp.cloudera.com", 443, "https");

      // specify the get request
      HttpGet getRequest = new HttpGet("/dwx/api/v2/environments");
      getRequest.setHeader("Cookie", "cdp-session-token=" + sessionToken);

      DysonMain.logger.debug("executing request to " + target);

      HttpResponse httpResponse = httpClient.execute(target, getRequest);
      HttpEntity entity = httpResponse.getEntity();

      for (Header h : getRequest.getAllHeaders()) {
        DysonMain.logger.debug("request header: " + h);
      }

      DysonMain.logger.debug(httpResponse.getStatusLine());
      Header[] headers = httpResponse.getAllHeaders();
      for (int i = 0; i < headers.length; i++) {
        DysonMain.logger.debug("response header: " + headers[i]);
      }

      if (entity != null) {
        DysonMain.logger.debug(EntityUtils.toString(entity));
      }
    } catch (IOException ioe) {
      throw new RuntimeException(ioe);
    } finally {
      httpClient.getConnectionManager().shutdown();
    }

  }

}
