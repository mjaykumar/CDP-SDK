package com.cloudera.dyson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class ShellBasedDataplaneClient {

  public static String[] getInstanceIdsForCluster(String credentialsProfile,
      String clusterName) {

    Process process = null;
    try {
      String[] command = new String[3];
      command[0] = "bash";
      command[1] = "-c";
      command[2] = "dp distrox describe --profile " + credentialsProfile +
        " --name " + clusterName + " | grep instanceId | grep -o 'i-[0-9a-f]*'";
      DysonMain.logger.debug("executing command: {}", String.join(" ", command));
      process = Runtime.getRuntime().exec(command);
    } catch (IOException ioe) {
      throw new RuntimeException(ioe);
    }

    BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));

    List<String> result = new LinkedList<String>();
    try {
      String line;
      while ((line = in.readLine()) != null) {
        DysonMain.logger.trace("process output: {}", line);
        result.add(line);
      }
    } catch (IOException ioe) {
      throw new RuntimeException(ioe);
    }

    try {
      process.waitFor();
    } catch (InterruptedException ie) {
      throw new RuntimeException(ie);
    }

    DysonMain.logger.trace("process result: {}", process.exitValue());

    return result.toArray(new String[0]);
  }

}
