package com.cloudera.dyson;

import com.cloudera.cdp.datahub.model.ClusterSummary;
import com.cloudera.cdp.datalake.model.Datalake;
import com.cloudera.cdp.environments.model.EnvironmentSummary;
import com.cloudera.cdp.ml.model.Workspace;

import java.io.InputStream;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class InputOutputFormat {

  private static final String COMMENT_CHARACTER = "#";
  private static final String SEPARATOR_CHARACTER = "\t";

  private static final String ENV_PREFIX = "environment";
  private static final String DL_PREFIX = "datalake-cluster";
  private static final String DH_PREFIX = "datahub-cluster";
  private static final String ML_PREFIX = "ml-workspace";

  public static void printResourcesToStream(DeletionResources resources,
      PrintStream out, boolean printInstanceIds, String profileName) {
    out.println("# Generated " + LocalDate.now() + " " + LocalTime.now());

    out.println("\n# Environments: (" + resources.envs.size() + ")");
    for (EnvironmentSummary e : resources.envs) {
      printResource(out, ENV_PREFIX, e.getEnvironmentName(), e.getCrn(), "");
    }

    out.println("\n# Datalakes: (" + resources.dlClusters.size() + ")");
    for (Datalake d : resources.dlClusters) {
      printResource(out, DL_PREFIX, d.getDatalakeName(), d.getCrn(), "");
    }
    out.println(COMMENT_CHARACTER + " Total node count: "
        + (resources.dlClusters.size() * 2));

    int totalNodeCount = 0;
    out.println("\n# Datahub Clusters: (" + resources.dhClusters.size() + ")");
    for (ClusterSummary c : resources.dhClusters) {
      printResource(out, DH_PREFIX, c.getClusterName(), c.getCrn(), "");
      totalNodeCount += c.getNodeCount();
      if (printInstanceIds) {
        String[] instanceIds = ShellBasedDataplaneClient.getInstanceIdsForCluster(
            profileName, c.getClusterName());
        out.println("# instance-ids: " + String.join(",", instanceIds));
      }
    }
    out.println(COMMENT_CHARACTER + " Total node count: " + totalNodeCount);

    out.println("\n# ML Workspaces: (" + resources.mlWorkspaces.size() + ")");
    for (Workspace w : resources.mlWorkspaces) {
      printResource(out, ML_PREFIX, w.getInstanceName(), w.getCrn(),
          w.getEnvironmentName());
    }
  }

  private static void printResource(PrintStream out, String type, String name,
      String crn, String environmentName) {
    String[] output = {type, name, crn, environmentName};
    out.println(String.join(SEPARATOR_CHARACTER, output));
  }

  public static DeletionResources parseResourcesFromStream(InputStream in) {
    DeletionResources resources = new DeletionResources();

    Scanner scanner = new Scanner(in);
    while (scanner.hasNextLine()) {
      String line = scanner.nextLine().trim();
      DysonMain.logger.trace("Read line {}", line);
      if (line.startsWith(COMMENT_CHARACTER) || line.isEmpty())
        continue;

      String[] tokens = line.split(SEPARATOR_CHARACTER);
      if (!(tokens.length == 3 || tokens.length == 4)) {
        throw new RuntimeException("Could not parse line '" + line + "'");
      }

      readResource(tokens, resources);
    }

    DysonMain.logger.debug("Parsed {} environments, {} Datalakes, " +
        "{} Datahub clusters, and {} ML workspaces", resources.envs.size(),
        resources.dlClusters.size(), resources.dhClusters.size(),
        resources.mlWorkspaces.size());
    return resources;
  }

  private static void readResource(String[] tokens,
      DeletionResources resources) {

      if (ENV_PREFIX.equals(tokens[0])) {
        DysonMain.logger.trace("Read env {}", tokens[1]);

        EnvironmentSummary env = new EnvironmentSummary();
        env.setEnvironmentName(tokens[1]);
        env.setCrn(tokens[2]);
        resources.envs.add(env);
      } else if (DL_PREFIX.equals(tokens[0])) {
        DysonMain.logger.trace("Read DL {}", tokens[1]);

        Datalake dlCluster = new Datalake();
        dlCluster.setDatalakeName(tokens[1]);
        dlCluster.setCrn(tokens[2]);
        resources.dlClusters.add(dlCluster);
      } else if (DH_PREFIX.equals(tokens[0])) {
        DysonMain.logger.trace("Read DH {}", tokens[1]);

        ClusterSummary dhCluster = new ClusterSummary();
        dhCluster.setClusterName(tokens[1]);
        dhCluster.setCrn(tokens[2]);
        resources.dhClusters.add(dhCluster);
      } else if (ML_PREFIX.equals(tokens[0])) {
        DysonMain.logger.trace("Read ML {}", tokens[1]);

        Workspace mlWorkspace = new Workspace();
        mlWorkspace.setInstanceName(tokens[1]);
        mlWorkspace.setCrn(tokens[2]);
        mlWorkspace.setEnvironmentName(tokens[3]);
        resources.mlWorkspaces.add(mlWorkspace);
      } else {
        throw new RuntimeException("Could not parse first token '" + tokens[0]
            + "'");
      }
  }

}
